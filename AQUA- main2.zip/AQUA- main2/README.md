# AQUA
maritime route optimazation

unzipped the node_modules(contains the depth, land gird and also the node modules needed) and extract the contents in the root folder. 

To view or download the files, please click the link below.


**[Click here to access the Project Drive](https://drive.google.com/drive/folders/1axyjNdWWTPJFyT0RH5i_vWjxACgbHBeM?usp=sharing)**
